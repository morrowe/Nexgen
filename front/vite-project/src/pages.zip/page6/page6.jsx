import { useEffect, useRef, useState } from 'react';
import { NavLink } from 'react-router-dom'
import {im} from '../images/images.js';
import axios from "axios"
import styles from "./page6.module.scss"

function Page6() {
    const [testimonials, setTestimonials] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/testimonials")
        .then(res => setTestimonials(res.data))
        .catch(err => console.error(err));
    }, []);
    const [article, setArticle] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/article")
        .then(res => setArticle(res.data))
        .catch(err => console.error(err));
    }, []);
    const [faq, setFaq] = useState([]);
    const [openId, setOpenId] = useState(null);
    useEffect(() => {
    axios
        .get("http://localhost:3000/api/faq")
        .then((res) => setFaq(res.data))
        .catch((err) => console.error(err));
    }, []);
    return (
        <>
            <main className={styles.main}>
                <section className={styles.sect1}>
                    <div className={styles.head}>
                        <h3>Our Blogs</h3>
                    </div>
                    <div className={styles.title}>
                        <div className={styles.immg}>
                            <img src={im.stat} alt="" />
                        </div>
                        <div className={styles.block}>
                            <div>
                                <p className={styles.third}>Web Design Trends Shaping 2024</p>
                                <div>

                                </div>
                            </div>
                            <p>Stay ahead of the design curve with insights into the latest web design trends. From immersive user experiences to bold color choices, explore the design elements that will dominate the digital landscape in 2023 and beyond.</p>
                            <div className={styles.niz}>
                                <div>
                                    <img src="" alt="" />
                                    <p>Read Full Blog</p>
                                </div>
                                <div>
                                    <p>Published Date</p>
                                    <h4>7th February 2023</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className={styles.blogs}>
                        {article.map((item, index) => (
                        <div className={styles.container}>
                            <img src={item.img} alt="" />
                            <div className={styles.text}>
                                <h4>{item.headl}</h4>
                                <p>{item.text}</p>
                            </div>
                            <div className={styles.link}>
                                <img src={im.go2} alt="" />
                                <nav className={styles.nav}>
                                    <NavLink to={'/page7'} className={({isActive}) => (isActive ? "active":"")}>Read Full Blog</NavLink>
                                </nav>
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect2}>
                    <div className={styles.head}>
                        <h3>Testimonials</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Testimonials</p>
                        </div>
                    </div>
                    <div className={styles.blocks}>
                        {testimonials.map((item, index) => (
                        <div className={styles.card}>
                            <div className={styles.text}>
                                <h4>{item.head}</h4>
                                <p>{item.txt}</p>
                            </div>
                            <div className={styles.verh}>
                                <div className={styles.profil}>
                                    <img src={item.img} alt="" />
                                    <div>
                                        <p className={styles.fio}>{item.name}</p>
                                        <p className={styles.work}>{item.work}</p>
                                    </div>
                                </div>
                                <img src={im.go3} alt="" />
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect3}>
                    <div className={styles.head}>
                        <h3>Frequently Asked Questions</h3>
                        <div>
                        </div>
                    </div>
                    <div className={styles.ask}>
                        <div className={styles.info}>
                        {faq.map((item) => (
                        <div key={item.id} className={styles.faq} onClick={() => setOpenId(openId === item.id ? null : item.id)}>
                            <div className={styles.top}>
                                <p className={styles.twotwo}>{item.question}</p>
                                <img
                                src={
                                    openId === item.id
                                    ? im.minus
                                    : im.plus
                                }/>
                            </div>
                            {openId === item.id && (
                                <div className={styles.answer}>
                                <p>{item.answer}</p>
                                </div>
                            )}
                        </div>
                        ))}
                        </div>
                        <div className={styles.question}>
                            <h4>Ask your questions</h4>
                            <div className={styles.string}>
                                <div className={styles.namemail}>
                                    <p>Name</p>
                                    <input type="text" placeholder='Enter your name'/>
                                </div>
                                <div className={styles.namemail}>
                                    <p>Email</p>
                                    <input type="text" placeholder='Enter your email'/>
                                </div>
                                <div className={styles.quest}>
                                    <p>Your Question</p>
                                    <input type="text" placeholder='Enter Your Question Here .....'/>
                                </div>
                            </div>
                            <button>Send Your Message</button>
                        </div>
                    </div>    
                </section>
            </main>
        </>
    )
}
export default Page6