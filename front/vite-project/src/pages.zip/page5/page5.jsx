import { useEffect, useRef, useState } from 'react';
import {im} from '../images/images.js';
import axios from "axios"
import styles from "./page5.module.scss"



function Page5() {

    const [testimonials, setTestimonials] = useState([]); 
    useEffect(() => {
    axios.get("http://localhost:3000/api/testimonials")
    .then(res => setTestimonials(res.data))
    .catch(err => console.error(err));
    }, []);
    const [faq, setFaq] = useState([]);
    const [openId, setOpenId] = useState(null);
    useEffect(() => {
    axios
        .get("http://localhost:3000/api/faq")
        .then((res) => setFaq(res.data))
        .catch((err) => console.error(err));
    }, []);
    const [jointeam, setJointeam] = useState([]); 
    useEffect(() => {
    axios.get("http://localhost:3000/api/jointeam")
    .then(res => setJointeam(res.data))
    .catch(err => console.error(err));
    }, []);
    const [apply, setApply] = useState([]); 
    useEffect(() => {
    axios.get("http://localhost:3000/api/apply")
    .then(res => setApply(res.data))
    .catch(err => console.error(err));
    }, []);
    return (
        <>
            <main className={styles.main}>
                <section className={styles.sect1}>
                    <div className={styles.top}>
                        <div className={styles.left}>
                        <div className={styles.start}>
                            <div className={styles.headline}>
                            <div>
                                <h2>Unlock Your Potential</h2>
                                <button>
                                <img src={im.startb} alt="" />
                                START A PROJECT
                                </button>
                            </div>
                            <h2>in the Digital World</h2>
                            </div>
                        </div>
                        </div>
                        <div className={styles.right}>
                            <div className={styles.image}>
                                <p className={styles.third}>At NexGen</p>
                                <p className={styles.text}>We believe in fostering a dynamic and collaborative work environment that empowers our team members to excel in their respective fields. Join us to be part of a passionate and innovative team dedicated to crafting exceptional digital solutions for clients across the globe. We are committed to nurturing talent, encouraging professional growth, and creating a workplace where creativity thrives.</p>
                            </div>
                            <div className={styles.buttons}>
                                <img src={im.go5} alt="" />
                                <p>Know More</p>
                            </div>
                        </div>
                    </div>
                </section>
                <section className={styles.sect2}>
                    <div className={styles.head}>
                        <h3>Join Our Team at NexGen</h3>
                    </div>
                    <div className={styles.join}>
                        {jointeam.map((item, index) => (
                        <div className={styles.section}>
                            <div className={styles.name}>
                                <div>
                                    <img src={item.img} alt="" />
                                    <p className={styles.third}>{item.head}</p>
                                </div>
                                <div>
                                    <img src={im.go2} alt="" />
                                    <p>View Details</p>
                                </div>
                            </div>
                            <div className={styles.categor}>
                                <div>
                                    <p>Salary <span>•</span> {item.salary}</p>
                                </div>
                                <div>
                                    <p>Experience <span>•</span>{item.experience}</p>
                                </div>
                                <div>
                                    <p>Deadline <span>•</span>{item.deadline}</p>
                                </div>
                            </div>
                            <div className={styles.text}>
                                <h4>Skills</h4>
                                <p>{item.text}</p>
                            </div>
                            <button>Apply NoW</button>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect3}>
                    <div className={styles.head}>
                        <h3>How to Apply</h3>
                    </div>
                    <div>
                        {apply.map((item, index) => (
                        <div>
                            <p>{item.step}</p>
                            <div>
                                <h4>{item.headline}</h4>
                            </div>
                            <div>
                                <p>{item.info}</p>
                            </div>
                            <div>
                                <img src={im.go5} alt="" />
                                <p>Know More</p>
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect4}>
                    <div className={styles.head}>
                        <h3>Testimonials</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Testimonials</p>
                        </div>
                    </div>
                    <div className={styles.blocks}>
                        {testimonials.map((item, index) => (
                        <div className={styles.card}>
                            <div className={styles.text}>
                                <h4>{item.head}</h4>
                                <p>{item.txt}</p>
                            </div>
                            <div className={styles.verh}>
                                <div className={styles.profil}>
                                    <img src={item.img} alt="" />
                                    <div>
                                        <p className={styles.fio}>{item.name}</p>
                                        <p className={styles.work}>{item.work}</p>
                                    </div>
                                </div>
                                <img src={im.go3} alt="" />
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect5}>
                    <div className={styles.head}>
                        <h3>Frequently Asked Questions</h3>
                        <div>
                        </div>
                    </div>
                    <div className={styles.ask}>
                        <div className={styles.info}>
                        {faq.map((item) => (
                        <div key={item.id} className={styles.faq} onClick={() => setOpenId(openId === item.id ? null : item.id)}>
                            <div className={styles.top}>
                                <p className={styles.twotwo}>{item.question}</p>
                                <img
                                src={
                                    openId === item.id
                                    ? im.minus
                                    : im.plus
                                }/>
                            </div>
                            {openId === item.id && (
                                <div className={styles.answer}>
                                <p>{item.answer}</p>
                                </div>
                            )}
                        </div>
                        ))}
                        </div>
                        <div className={styles.question}>
                            <h4>Ask your questions</h4>
                            <div className={styles.string}>
                                <div className={styles.namemail}>
                                    <p>Name</p>
                                    <input type="text" placeholder='Enter your name'/>
                                </div>
                                <div className={styles.namemail}>
                                    <p>Email</p>
                                    <input type="text" placeholder='Enter your email'/>
                                </div>
                                <div className={styles.quest}>
                                    <p>Your Question</p>
                                    <input type="text" placeholder='Enter Your Question Here .....'/>
                                </div>
                            </div>
                            <button>Send Your Message</button>
                        </div>
                    </div>    
                </section>
            </main>
        </>
    )
}
export default Page5