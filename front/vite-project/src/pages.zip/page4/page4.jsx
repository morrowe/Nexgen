import { useEffect, useRef, useState } from 'react';
import {im} from '../images/images.js';
import axios from "axios"
import styles from "./page4.module.scss"

function Page4() {
    const [more2, setMore2] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/more2")
        .then(res => setMore2(res.data))
        .catch(err => console.error(err));
    }, []);
    const [testimonials, setTestimonials] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/testimonials")
        .then(res => setTestimonials(res.data))
        .catch(err => console.error(err));
    }, []);
    const [faq, setFaq] = useState([]);
    const [openId, setOpenId] = useState(null);
    useEffect(() => {
        axios
        .get("http://localhost:3000/api/faq")
        .then((res) => setFaq(res.data))
        .catch((err) => console.error(err));
    }, []);
    const [minds, setMinds] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/minds")
        .then(res => setMinds(res.data))
        .catch(err => console.error(err));
    }, []);
    const [achiev, setAchiev] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/achiev")
        .then(res => setAchiev(res.data))
        .catch(err => console.error(err));
    }, []);
    const [awre, setAwre] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/awre")
        .then(res => setAwre(res.data))
        .catch(err => console.error(err));
    }, []);

    return (
        <>
            <main className={styles.main}>
                <section className={styles.sect1}>
                    <div className={styles.top}>
                        <div className={styles.left}>
                        <div className={styles.start}>
                            <div className={styles.headline}>
                            <div>
                                <h2>Elevating Brands</h2>
                                <button>
                                <img src={im.startb} alt="" />
                                START A PROJECT
                                </button>
                            </div>
                            <h2>in the Digital Age</h2>
                            </div>
                            <p className={styles.pp}>At NexGen, we offer a comprehensive suite of digital solutions designed to propel your business to new heights in the digital realm. With a team of skilled professionals, cutting-edge technologies, and a passion for innovation</p>
                        </div>
                        </div>
                        <div className={styles.right}>
                            <div className={styles.image}>
                                {more2.map((item, index) => (
                                    <div className={styles.block}>
                                        <p>{item.name}</p>
                                        <p className={styles.six}>{item.info}</p>
                                    </div>
                                ))}
                            </div>
                            <div className={styles.button}>
                                <img src={im.go5} alt="" />
                                <p>Know More</p>
                            </div>
                        </div>
                    </div>
                </section>
                <section className={styles.sect2}>
                    <div className={styles.head}>
                        <h3>Meet the brilliant minds behind NexGen</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Members</p>
                        </div>
                    </div>
                    <div className={styles.group}>
                        {minds.map((item, index) => (
                        <div className={styles.content}>
                            <div>
                                <h4>{item.name}</h4>
                                <p>{item.work}</p>
                            </div>
                            <div className={styles.backg} style={{ backgroundImage: `url(${item.img})`}}></div>
                            <div className={styles.butt}>
                                <button><img src={im.facebook} alt="" /></button>
                                <button><img src={im.twitter} alt="" /></button>
                                <button><img src={im.inl} alt="" /></button>
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect3}>
                    <div className={styles.head}>
                        <h3>Our Achievements</h3>
                    </div>
                    <div className={styles.container}>
                        {achiev.map((item, index) => (
                        <div className={styles.content}>
                            <p className={styles.data}>{item.data}</p>
                            <div className={styles.headline}>
                                <h4>{item.headline}</h4>
                            </div>
                            <div className={styles.info}><p>{item.info}</p></div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect4}>
                    <div className={styles.head}>
                        <h3>Awards & Recognitions</h3>
                    </div>
                    <div className={styles.content}>
                        {awre.map((item, index) => (
                        <div className={styles.info}>
                            <div className={styles.div}>
                                <div><p>Date </p><p className={styles.span}>•</p> <p> {item.date}</p></div>
                                <img src={im.priz} alt="" />
                            </div>
                            <p className={styles.third}>{item.head}</p>
                            <p className={styles.txt}>{item.text}</p>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect5}>
                    <div className={styles.head}>
                        <h3>Testimonials</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Testimonials</p>
                        </div>
                    </div>
                    <div className={styles.blocks}>
                        {testimonials.map((item, index) => (
                        <div className={styles.card}>
                            <div className={styles.text}>
                                <h4>{item.head}</h4>
                                <p>{item.txt}</p>
                            </div>
                            <div className={styles.verh}>
                                <div className={styles.profil}>
                                    <img src={item.img} alt="" />
                                    <div>
                                        <p className={styles.fio}>{item.name}</p>
                                        <p className={styles.work}>{item.work}</p>
                                    </div>
                                </div>
                                <img src={im.go3} alt="" />
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect6}>
                    <div className={styles.head}>
                        <h3>Frequently Asked Questions</h3>
                        <div>
    
                        </div>
                    </div>
                    <div className={styles.ask}>
                        <div className={styles.info}>
                        {faq.map((item) => (
                        <div key={item.id} className={styles.faq} onClick={() => setOpenId(openId === item.id ? null : item.id)}>
                            <div className={styles.top}>
                                <p className={styles.twotwo}>{item.question}</p>
                                <img
                                src={
                                    openId === item.id
                                    ? im.minus
                                    : im.plus
                                }/>
                            </div>
                            {openId === item.id && (
                                <div className={styles.answer}>
                                <p>{item.answer}</p>
                                </div>
                            )}
                        </div>
                        ))}
                        </div>
                        <div className={styles.question}>
                            <h4>Ask your questions</h4>
                            <div className={styles.string}>
                                <div className={styles.namemail}>
                                    <p>Name</p>
                                    <input type="text" placeholder='Enter your name'/>
                                </div>
                                <div className={styles.namemail}>
                                    <p>Email</p>
                                    <input type="text" placeholder='Enter your email'/>
                                </div>
                                <div className={styles.quest}>
                                    <p>Your Question</p>
                                    <input type="text" placeholder='Enter Your Question Here .....'/>
                                </div>
                            </div>
                            <button>Send Your Message</button>
                        </div>
                    </div>    
                </section>
            </main>
        </>
    )
}
export default Page4