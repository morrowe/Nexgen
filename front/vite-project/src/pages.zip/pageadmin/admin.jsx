import { useEffect, useState } from 'react';
import axios from "axios";
import styles from "./admin.module.scss";
import {im} from '../images/images.js';

function Admin() {
    
    
    return (
        <main>
            <div className={styles.navidate}>
                <button>Home</button>
                <button>Services</button>
                <button>Pojects</button>
                <button>About</button>
                <button>Careers</button>
                <button>Blogs</button>
                <button>Contact</button>
            </div>
            <section>

            </section>
        </main>
    );
}

export default Admin;