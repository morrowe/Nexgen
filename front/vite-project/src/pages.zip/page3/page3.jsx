import { useEffect, useRef, useState } from 'react';
import {im} from '../images/images.js';
import axios from "axios"
import styles from "./page3.module.scss"

function Page3() {
    const [projects, setProjects] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/projects")
        .then(res => setProjects(res.data))
        .catch(err => console.error(err));
    }, []);
    const [works, setWorks] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/works")
        .then(res => setWorks(res.data))
        .catch(err => console.error(err));
    }, []);
    const [testimonials, setTestimonials] = useState([]); 
    useEffect(() => {
        axios.get("http://localhost:3000/api/testimonials")
        .then(res => setTestimonials(res.data))
        .catch(err => console.error(err));
    }, []);
    const [faq, setFaq] = useState([]);
    const [openId, setOpenId] = useState(null);
    useEffect(() => {
        axios
        .get("http://localhost:3000/api/faq")
        .then((res) => setFaq(res.data))
        .catch((err) => console.error(err));
    }, []);
    

    return (
        <>
            <main className={styles.main}>
                <section className={styles.sect1}>
                    <div className={styles.top}>
                        <div className={styles.left}>
                        <div className={styles.start}>
                            <div className={styles.headline}>
                            <div>
                                <h2>Empowering Your</h2>
                                <button>
                                <img src={im.startb} alt="" />
                                START A PROJECT
                                </button>
                            </div>
                            <h2>Digital Vision</h2>
                            </div>
                            <p className={styles.pp}>At NexGen, we offer a comprehensive suite of digital solutions designed to propel your business to new heights in the digital realm. With a team of skilled professionals, cutting-edge technologies, and a passion for innovation</p>
                        </div>
                        </div>
                        <div className={styles.right}>
                        <div className={styles.image}>
                            <div className={styles.texts}>
                            <button>Web Development.</button>  
                            <div>
                                <img src={im.go4} alt="" />
                                <p>View Blog</p>
                            </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </section>
                <section className={styles.sect2}>
                    <div className={styles.head}>
                        <h3>Key Features of Our Projects</h3>
                    </div>
                    <div className={styles.more}>
                        {projects.map((item, index) => (
                        <div className={styles.content}>
                            <div className={styles.image}>
                                <img src={item.img} alt="" />
                            </div>
                            <div className={styles.block}>
                                <p className={styles.third}>{item.name}</p>
                                <p>{item.text}</p>
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect3}>
                    <div className={styles.head}>
                        <h3>Projects Showcase</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Works</p>
                        </div>
                    </div>
                    <div className={styles.cards}>
                        {works.map((item, index) => (
                        <div className={styles.card}>
                            <div className={styles.detail}>
                                <div className={styles.name}>
                                    <img src={item.img} alt="" />
                                    <h4>{item.headline}</h4>
                                   <div>
                                    <img src={im.go2} alt="" />
                                    <p>Details</p>
                                   </div>
                                </div>
                                <div className={styles.resurs}>
                                    <div className={styles.categ}>
                                        <p>Category</p><p className={styles.dot}>•</p> <p className={styles.grey}>{item.category}</p>
                                    </div>
                                    <div className={styles.time}>
                                        <p>Time Taken</p> <p className={styles.dot}>•</p> <p className={styles.grey}>{item.time}</p>
                                    </div>
                                </div>
                                <p className={styles.txt}>{item.text}</p>
                            </div>
                            <div className={styles.backgr} style={{ backgroundImage: `url(${item.bacgr})` }}></div>
                            <div className={styles.info}>
                                <div className={styles.used}>
                                    <p className={styles.wh}>Technologies Used</p>
                                    <div>
                                        <p>{item.used1}</p>
                                        <p>{item.used2}</p>
                                        <p>{item.used3}</p>
                                        <p>{item.used4}</p>
                                        <p>{item.used5}</p>
                                    </div>
                                </div>
                                <div className={styles.team}>
                                    <p>Team Members</p>
                                    <div className={styles.people}>
                                        <img src={item.team1} alt="" />
                                        <img src={item.team2} alt="" />
                                        <img src={item.team3} alt="" />
                                        <img src={item.team4} alt="" />
                                        <img src={item.team5} alt="" />
                                    </div>    
                                </div>
                                <button className={styles.button}>Book A Call</button>
                            </div>
                        </div>
                        ))}
                    </div>    
                </section>
                <section className={styles.sect4}>
                    <div className={styles.head}>
                        <h3>Testimonials</h3>
                        <div>
                            <img src={im.go2} alt="" />
                            <p>ALL Testimonials</p>
                        </div>
                    </div>
                    <div className={styles.blocks}>
                        {testimonials.map((item, index) => (
                        <div className={styles.card}>
                            <div className={styles.text}>
                                <h4>{item.head}</h4>
                                <p>{item.txt}</p>
                            </div>
                            <div className={styles.verh}>
                                <div className={styles.profil}>
                                    <img src={item.img} alt="" />
                                    <div>
                                        <p className={styles.fio}>{item.name}</p>
                                        <p className={styles.work}>{item.work}</p>
                                    </div>
                                </div>
                                <img src={im.go3} alt="" />
                            </div>
                        </div>
                        ))}
                    </div>
                </section>
                <section className={styles.sect5}>
                    <div className={styles.head}>
                        <h3>Frequently Asked Questions</h3>
                        <div>
    
                        </div>
                    </div>
                    <div className={styles.ask}>
                        <div className={styles.info}>
                        {faq.map((item) => (
                        <div key={item.id} className={styles.faq} onClick={() => setOpenId(openId === item.id ? null : item.id)}>
                            <div className={styles.top}>
                                <p className={styles.twotwo}>{item.question}</p>
                                <img
                                src={
                                    openId === item.id
                                    ? im.minus
                                    : im.plus
                                }/>
                            </div>
                            {openId === item.id && (
                                <div className={styles.answer}>
                                <p>{item.answer}</p>
                                </div>
                            )}
                        </div>
                        ))}
                        </div>
                        <div className={styles.question}>
                            <h4>Ask your questions</h4>
                            <div className={styles.string}>
                                <div className={styles.namemail}>
                                    <p>Name</p>
                                    <input type="text" placeholder='Enter your name'/>
                                </div>
                                <div className={styles.namemail}>
                                    <p>Email</p>
                                    <input type="text" placeholder='Enter your email'/>
                                </div>
                                <div className={styles.quest}>
                                    <p>Your Question</p>
                                    <input type="text" placeholder='Enter Your Question Here .....'/>
                                </div>
                            </div>
                            <button>Send Your Message</button>
                        </div>
                    </div>    
                </section>
            </main>
        </>
    )
}
export default Page3